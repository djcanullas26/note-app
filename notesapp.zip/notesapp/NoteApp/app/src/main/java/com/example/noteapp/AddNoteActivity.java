package com.example.noteapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddNoteActivity extends AppCompatActivity {
    EditText title, content;
    Button saveNoteBtn;
    String user_id;

    Button deleteNoteBtn;
    int note_id = -1;  // Default to -1 (no note)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        // Retrieve the user_id and note_id from the Intent
        user_id = getIntent().getStringExtra("user_id");
        note_id = getIntent().getIntExtra("note_id", -1); // Get note_id, default to -1 if not passed

        title = findViewById(R.id.noteTitle);
        content = findViewById(R.id.noteContent);
        saveNoteBtn = findViewById(R.id.saveNoteButton);

        // If editing, load the note data
        if (note_id != -1) {
            loadNoteData();
        }

        // Set click listener for saving or updating the note
        saveNoteBtn.setOnClickListener(v -> {
            if (note_id == -1) {
                saveNote();  // Adding a new note
            } else {
                updateNote();  // Editing an existing note
            }
        });

        deleteNoteBtn = findViewById(R.id.deleteNoteButton);
         if (note_id != -1) {
            loadNoteData();
            deleteNoteBtn.setVisibility(View.VISIBLE); // show delete button
        }

        deleteNoteBtn.setOnClickListener(v -> deleteNote());

    }

    // Method to save a new note
    void saveNote() {
        String t = title.getText().toString();
        String c = content.getText().toString();

        StringRequest request = new StringRequest(Request.Method.POST, "http://10.0.2.2/notesapp/add_note.php",
                response -> {
                    if (response.equals("success")) {
                        Toast.makeText(this, "Note Saved", Toast.LENGTH_SHORT).show();
                        finish();  // Close the activity after saving
                    } else {
                        Toast.makeText(this, "Failed to save", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", user_id);
                map.put("title", t);
                map.put("content", c);
                return map;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    // Method to update an existing note
    void updateNote() {
        String t = title.getText().toString().trim();
        String c = content.getText().toString().trim();

        StringRequest request = new StringRequest(Request.Method.POST, "http://10.0.2.2/notesapp/update_note.php",
                response -> {
                    if (response.equalsIgnoreCase("success")) {
                        Toast.makeText(this, "Note Updated", Toast.LENGTH_SHORT).show();
                        finish(); // Go back to previous screen
                    } else {
                        Toast.makeText(this, "Failed to update note", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("note_id", String.valueOf(note_id));
                map.put("title", t);
                map.put("content", c);
                return map;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }


    // Method to load the data of an existing note for editing
    void loadNoteData() {
        String url = "http://10.0.2.2/notesapp/get_single_note.php?note_id=" + note_id;

        StringRequest req = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        if (obj.has("error")) {
                            Toast.makeText(this, "Note not found", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        title.setText(obj.getString("title"));
                        content.setText(obj.getString("content"));
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Parse error", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error loading note", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(req);
    }

    void deleteNote() {
        StringRequest request = new StringRequest(Request.Method.POST, "http://10.0.2.2/notesapp/delete_note.php",
                response -> {
                    if (response.equalsIgnoreCase("success")) {
                        Toast.makeText(this, "Note Deleted", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "Failed to delete", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("note_id", String.valueOf(note_id));
                return map;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }


}
