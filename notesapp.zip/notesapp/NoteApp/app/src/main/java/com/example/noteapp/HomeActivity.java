package com.example.noteapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {
    ListView notesList;
    Button addNoteBtn;
    String user_id;

    ArrayList<String> noteTitles = new ArrayList<>();
    ArrayList<Integer> noteIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        user_id = getIntent().getStringExtra("user_id");

        notesList = findViewById(R.id.notesList);
        addNoteBtn = findViewById(R.id.addNoteButton);

        addNoteBtn.setOnClickListener(v -> {
            Intent i = new Intent(this, AddNoteActivity.class);
            i.putExtra("user_id", user_id);
            startActivity(i);
        });

        notesList.setOnItemClickListener((parent, view, position, id) -> {
            int note_id = noteIds.get(position);
            Intent i = new Intent(this, AddNoteActivity.class);
            i.putExtra("user_id", user_id);
            i.putExtra("note_id", note_id);
            startActivity(i);
        });
    }

    void loadNotes() {
        String url = "http://10.0.2.2/notesapp/get_notes.php?user_id=" + user_id;

        StringRequest req = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONArray array = new JSONArray(response);
                        noteTitles.clear();
                        noteIds.clear();

                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);
                            noteTitles.add(obj.getString("title") + "\n" + obj.getString("content"));
                            noteIds.add(obj.getInt("id"));
                        }

                        notesList.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, noteTitles));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Failed to parse notes", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e("LOAD_NOTES", "Volley error: " + error.toString());
                    Toast.makeText(this, "Error loading notes", Toast.LENGTH_SHORT).show();
                }
        );

        Volley.newRequestQueue(this).add(req);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }
}
