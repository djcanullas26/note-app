package com.example.noteapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    EditText email, password;
    Button login, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login = findViewById(R.id.loginButton);
        register = findViewById(R.id.registerButton);

        login.setOnClickListener(v -> loginUser());
        register.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
    }

    void loginUser() {
        String e = email.getText().toString();
        String p = password.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://10.0.2.2/notesapp/login.php",
                response -> {
                    if (response.equals("invalid") || response.equals("not_found")) {
                        Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent intent = new Intent(this, HomeActivity.class);
                        intent.putExtra("user_id", response);
                        startActivity(intent);
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("email", e);
                map.put("password", p);
                return map;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
